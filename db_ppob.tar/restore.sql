--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.1
-- Dumped by pg_dump version 10.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

DROP TABLE public.tb_level;
DROP TABLE public.tb_admin;
DROP TABLE public.tarif;
DROP TABLE public.tagihan;
DROP TABLE public.penggunaan;
DROP TABLE public.pembayaran;
DROP TABLE public.pelanggan;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: pelanggan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE pelanggan (
    id_pelanggan character varying(12),
    username character varying(100),
    password character varying(100),
    nomor_kwh integer,
    alamat text,
    id_tarif character varying
);


ALTER TABLE pelanggan OWNER TO postgres;

--
-- Name: pembayaran; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE pembayaran (
    id_pembayaran character varying(12),
    id_tagihan character varying(100),
    id_pelanggan character varying(100),
    tanggal_pembayaran date,
    bulan_bayar date,
    biaya_admin date,
    total_bayar integer,
    id_admin character varying(100)
);


ALTER TABLE pembayaran OWNER TO postgres;

--
-- Name: penggunaan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE penggunaan (
    id_penggunaan character varying(12),
    id_pelanggan character varying(12),
    bulan date,
    tahun date,
    meter_awal integer,
    meter_ahir integer
);


ALTER TABLE penggunaan OWNER TO postgres;

--
-- Name: tagihan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tagihan (
    id_tagihan character varying(12),
    id_penggunaan character varying(12),
    id_pelanggan character varying(12),
    bulan date,
    tahun date,
    jumlah_meter bigint,
    status character varying(2)
);


ALTER TABLE tagihan OWNER TO postgres;

--
-- Name: tarif; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tarif (
    id_tarif character varying(100),
    daya integer,
    tarifperkwh bigint
);


ALTER TABLE tarif OWNER TO postgres;

--
-- Name: tb_admin; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_admin (
    id_admin character varying(12),
    username character varying(100),
    password character varying(100),
    id_level character varying(12)
);


ALTER TABLE tb_admin OWNER TO postgres;

--
-- Name: tb_level; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_level (
    id_level character varying(12),
    nama_level text
);


ALTER TABLE tb_level OWNER TO postgres;

--
-- Data for Name: pelanggan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY pelanggan (id_pelanggan, username, password, nomor_kwh, alamat, id_tarif) FROM stdin;
\.
COPY pelanggan (id_pelanggan, username, password, nomor_kwh, alamat, id_tarif) FROM '$$PATH$$/2817.dat';

--
-- Data for Name: pembayaran; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY pembayaran (id_pembayaran, id_tagihan, id_pelanggan, tanggal_pembayaran, bulan_bayar, biaya_admin, total_bayar, id_admin) FROM stdin;
\.
COPY pembayaran (id_pembayaran, id_tagihan, id_pelanggan, tanggal_pembayaran, bulan_bayar, biaya_admin, total_bayar, id_admin) FROM '$$PATH$$/2819.dat';

--
-- Data for Name: penggunaan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY penggunaan (id_penggunaan, id_pelanggan, bulan, tahun, meter_awal, meter_ahir) FROM stdin;
\.
COPY penggunaan (id_penggunaan, id_pelanggan, bulan, tahun, meter_awal, meter_ahir) FROM '$$PATH$$/2815.dat';

--
-- Data for Name: tagihan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tagihan (id_tagihan, id_penggunaan, id_pelanggan, bulan, tahun, jumlah_meter, status) FROM stdin;
\.
COPY tagihan (id_tagihan, id_penggunaan, id_pelanggan, bulan, tahun, jumlah_meter, status) FROM '$$PATH$$/2816.dat';

--
-- Data for Name: tarif; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tarif (id_tarif, daya, tarifperkwh) FROM stdin;
\.
COPY tarif (id_tarif, daya, tarifperkwh) FROM '$$PATH$$/2818.dat';

--
-- Data for Name: tb_admin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_admin (id_admin, username, password, id_level) FROM stdin;
\.
COPY tb_admin (id_admin, username, password, id_level) FROM '$$PATH$$/2820.dat';

--
-- Data for Name: tb_level; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_level (id_level, nama_level) FROM stdin;
\.
COPY tb_level (id_level, nama_level) FROM '$$PATH$$/2821.dat';

--
-- PostgreSQL database dump complete
--

